package api.test;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import api.endpoints.Authencationendpoints;
import io.restassured.response.Response;

public class AuthTests {
	@Test(priority = 1)
    public void testBasicAuth() {
        Response res = Authencationendpoints.basicAuthentication("postman", "password");
        res.then().log().all();
        assertEquals(res.getStatusCode(), 200);
    }

    @Test(priority = 2)
    public void testDigestAuth() {
        Response res = Authencationendpoints.digestAuthentication("postman", "password");
        res.then().log().all();
        assertEquals(res.getStatusCode(), 200);
    }

    @Test(priority = 3)
    public void testPreemptiveBasicAuth() {
        Response res = Authencationendpoints.preemptiveBasicAuthentication("postman", "password");
        res.then().log().all();
        assertEquals(res.getStatusCode(), 200);
    }

    @Test(priority = 4)
    public void testBearerToken() {
        String token = "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"; // Replace with actual token
        Response res = Authencationendpoints.bearerTokenAuthentication(token);
        res.then().log().all();
        assertEquals(res.getStatusCode(), 200);
    }

    @Test(priority = 5)
    public void testOAuth2() {
        String token = "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"; // GitHub personal access token works for OAuth2
        Response res = Authencationendpoints.oauth2Authentication(token);
        res.then().log().all();
        assertEquals(res.getStatusCode(), 200);
    }

    @Test(priority = 6)
    public void testApiKey() {
        String key = "your_openweather_api_key"; // Replace with actual OpenWeatherMap API key
        Response res = Authencationendpoints.apiKeyAuthentication(key);
        res.then().log().all();
        assertEquals(res.getStatusCode(), 200);
    }

}
